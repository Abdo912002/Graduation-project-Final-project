# Sprints Multi-Agent AI Career & Assessment Orchestrator

## About
This project is a multi-agent system built with LangGraph. It serves as an orchestrator to route queries to either an Advisor Agent (for student data) or an Assessor Agent (for Python code execution and fixing).

## Features
- **Orchestrator**: Routes requests.
- **Advisor Agent**: Queries student data from `sprints_learner_db.csv`.
- **Assessor Agent**: Uses Python REPL to execute and fix Python code.
- **MemorySaver**: Persists conversation state across threads.
- **HITL**: Human-in-the-loop escalation for complex errors.