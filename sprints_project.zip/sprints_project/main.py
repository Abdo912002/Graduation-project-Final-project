import os
from dotenv import load_dotenv
load_dotenv()

import pandas as pd
from langchain_groq import ChatGroq
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver
from typing import TypedDict, Annotated, Sequence
import operator

# 1. LLM
llm = ChatGroq(model="openai/gpt-oss-120b", temperature=0)

# 2. Data
try:
    df = pd.read_csv("sprints_learner_db.csv", on_bad_lines='skip')
    print(f"✅ تم تحميل {len(df)} طالب بنجاح.")
except Exception as e:
    print(f"❌ مشكلة في الملف: {e}")
    df = pd.DataFrame()

# 3. State
class AgentState(TypedDict):
    messages: Annotated[Sequence, operator.add]
    next_step: str

# 4. Nodes
def orchestrator_node(state: AgentState):
    print("\n--- [Orchestrator]: توجيه المهمة... ---")
    query = state["messages"][-1].content.lower()
    if "code" in query or "run" in query or "print" in query or "fix" in query:
        return {"next_step": "assessor"}
    return {"next_step": "advisor"}

def advisor_node(state: AgentState):
    print("\n--- [Advisor Agent]: الرد على الطالب... ---")
    query = state["messages"][-1].content
    # نبحث عن رقم الطالب في النص
    student_id = next((word for word in query.split() if word.startswith("SPR-")), None)
    
    if student_id and not df.empty:
        student = df[df['learner_id'] == student_id]
        if not student.empty:
            info = student.to_string(index=False)
            print(f"🛠️ [Tool Call]: تم جلب بيانات {student_id}")
            print(f"\n🤖 Final Answer:\n{info}")
            return {"messages": [AIMessage(content=info)]}
    
    # لو مش عن طالب، نرد بالـ LLM
    res = llm.invoke([SystemMessage(content="You are the Sprints Advisor. Answer briefly.")] + list(state["messages"]))
    print(f"\n🤖 Final Answer:\n{res.content}")
    return {"messages": [res]}

def assessor_node(state: AgentState):
    print("\n--- [Assessor Agent]: تقييم الكود... ---")
    query = state["messages"][-1].content
    
    # نستخرج الكود بعد النقطتين
    if ":" in query:
        code_to_run = query.split(":", 1)[-1].strip()
    else:
        code_to_run = query
        
    print(f"🛠️ [Tool Call]: تشغيل الكود...")
    try:
        # نستخدم exec عشان نشغل الكود بأمان هنا
        local_vars = {}
        exec(code_to_run, {}, local_vars)
        output = local_vars.get('output', "الكود اشتغل تمام")
        print(f"📥 [Tool Output]: {output}")
        final_msg = f"الكود شغال تمام. الناتج: {output}"
    except Exception as e:
        print(f"📥 [Tool Output]: {e}")
        # نطلب من الـ LLM يشرح الخطأ ويصلحه
        prompt = f"الكود ده فيه خطأ: {code_to_run}\nالخطأ: {e}\nاشرح الخطأ بالعربي وقولي التصليح إيه."
        res = llm.invoke([SystemMessage(content="You are the Sprints Assessor."), HumanMessage(content=prompt)])
        final_msg = res.content

    print(f"\n🤖 Final Answer:\n{final_msg}")
    return {"messages": [AIMessage(content=final_msg)]}

# 5. Graph
workflow = StateGraph(AgentState)
workflow.add_node("orchestrator", orchestrator_node)
workflow.add_node("advisor", advisor_node)
workflow.add_node("assessor", assessor_node)
workflow.set_entry_point("orchestrator")

workflow.add_conditional_edges("orchestrator", lambda x: x["next_step"], {"advisor": "advisor", "assessor": "assessor"})
workflow.add_edge("advisor", END)
workflow.add_edge("assessor", END)

memory = MemorySaver()
app = workflow.compile(checkpointer=memory)

# 6. Run
def run_agent(query: str):
    print(f"\n{'='*60}\n👤 المستخدم: {query}\n{'='*60}")
    app.invoke({"messages": [HumanMessage(content=query)]}, {"configurable": {"thread_id": "1"}})

if __name__ == "__main__":
    # تجربة رقم 1 (طالب)
    run_agent("What is the target salary for learner SPR-1001?")
    
    print("\n\n")
    
    # تجربة رقم 2 (كود بايثون)
    run_agent("Can you run this code: print('Hello' + 5)")